<?php
define('G5_CERT_IN_PROG', true);
include_once('../../common.php');