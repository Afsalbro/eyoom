<?php
include_once('../common.php');

if ($eyoom['use_tag'] != 'y') alert('잘못된 접근입니다.');

define('_TAG_', true);