<?php
include_once('./_common.php');

$g5['title'] = '태그';

include_once('../_head.php');
include_once($tag_skin_path.'/index.skin.php');
include_once('../_tail.php');